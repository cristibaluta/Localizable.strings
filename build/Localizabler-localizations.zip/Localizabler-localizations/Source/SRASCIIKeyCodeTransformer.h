//
//  SRKeyCodeTransformer.h
//  ShortcutRecorder
//
//  Copyright 2006-2012 Contributors. All rights reserved.
//
//  License: BSD
//
//  Contributors:
//      Ilya Kulakov

#import "SRKeyCodeTransformer.h"


@interface SRASCIIKeyCodeTransformer : SRKeyCodeTransformer

@end
